import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
                Scanner input = new Scanner(System.in);

                System.out.println("Digite o nome do aluno: ");
                String nome = input.nextLine();

                System.out.println("Digite a primeira nota: ");
                double nota1 = input.nextDouble();

                System.out.println("Digite a segunda nota: ");
                double nota2 = input.nextDouble();

                double media = nota1 + nota2 / 2;

                System.out.println("Média: " + media);

                if (media >= 7) {
                    System.out.println(nome + " aprovado");
                } else if (media >= 5)
                    System.out.println(nome + " recuperação");
            }
        }
